public class nivas{

public static void main(String[] args){
 
 int x=4;
  add(x); 
 System.out.println(x);
 int s=x;
 System.out.println(s);
 
}

public static int  add (int x){

  x++;
 System.out.println(x);
 return x;
   }
 }
  

